import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "../pages/Index";
import Aprendizados from "../pages/Aprendizados";
import NotFound from "../pages/NotFound";

export default function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/aprendizados" element={<Aprendizados />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

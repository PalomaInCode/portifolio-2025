import { useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";

interface Section {
  title: string;
  subsections?: string[];
}

const sections: Section[] = [
  {
    title: "Fundamentos de Programação",
    subsections: ["Lógica", "Estruturas de Dados", "POO", "Boas Práticas"],
  },
  {
    title: "Desenvolvimento Web",
    subsections: ["HTML & CSS", "JavaScript", "React", "Tailwind"],
  },
  {
    title: "Banco de Dados",
    subsections: ["SQL", "Modelagem", "ORM", "Consultas Avançadas"],
  },
  {
    title: "Infraestrutura e DevOps",
    subsections: ["Docker", "CI/CD", "Cloud", "Monitoramento"],
  },
  {
    title: "Soft Skills e Carreira",
    subsections: ["Comunicação", "Trabalho em Equipe", "Gestão de Tempo"],
  },
];

export default function Aprendizados() {
  const [openSection, setOpenSection] = useState<string | null>(null);
  const toggleSection = (title: string) =>
    setOpenSection(openSection === title ? null : title);

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r shadow-md">
        <div className="p-4">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">
            Aprendizados
          </h2>
          <ul className="space-y-2">
            {sections.map((section) => (
              <li key={section.title}>
                <button
                  onClick={() => toggleSection(section.title)}
                  className="flex items-center justify-between w-full text-left text-gray-700 font-medium hover:text-blue-600"
                >
                  {section.title}
                  {openSection === section.title ? (
                    <ChevronDown size={18} />
                  ) : (
                    <ChevronRight size={18} />
                  )}
                </button>
                {openSection === section.title && (
                  <ul className="mt-2 ml-4 border-l border-gray-200 pl-3 space-y-1 text-sm text-gray-600">
                    {section.subsections?.map((sub) => (
                      <li
                        key={sub}
                        className="cursor-pointer hover:text-blue-600"
                      >
                        {sub}
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        </div>
      </aside>

      {/* Conteúdo (placeholder) */}
      <main className="flex-1 p-10">
        <h1 className="text-3xl font-bold mb-4 text-gray-800">
          Seus Aprendizados
        </h1>
        <p className="text-gray-600">
          Em breve aqui ficarão os detalhes de cada aprendizado! 😊
        </p>
      </main>
    </div>
  );
}
